```yaml
# example configuration:

tuyacovercustom:
  id: tuyacovercustom_1

uart:
  tx_pin: D0
  rx_pin: D1
  baud_rate: 9600
```