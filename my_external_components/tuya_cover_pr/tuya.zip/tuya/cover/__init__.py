import esphome.codegen as cg
from esphome.components import cover
import esphome.config_validation as cv
from esphome.const import CONF_MAX_VALUE, CONF_MIN_VALUE, CONF_RESTORE_MODE

from .. import CONF_TUYA_ID, Tuya, tuya_ns

DEPENDENCIES = ["tuya"]

CONF_CONTROL_DATAPOINT = "control_datapoint"
CONF_DIRECTION_DATAPOINT = "direction_datapoint"
CONF_POSITION_DATAPOINT = "position_datapoint"
CONF_POSITION_REPORT_DATAPOINT = "position_report_datapoint"
CONF_INVERT_POSITION = "invert_position"
CONF_INVERT_POSITION_REPORT = "invert_position_report"
CONF_OPEN_VALUE = "open_value"
CONF_CLOSE_VALUE = "close_value"
CONF_STOP_VALUE = "stop_value"

TuyaCover = tuya_ns.class_("TuyaCover", cover.Cover, cg.Component)

TuyaCoverRestoreMode = tuya_ns.enum("TuyaCoverRestoreMode")
RESTORE_MODES = {
    "NO_RESTORE": TuyaCoverRestoreMode.COVER_NO_RESTORE,
    "RESTORE": TuyaCoverRestoreMode.COVER_RESTORE,
    "RESTORE_AND_CALL": TuyaCoverRestoreMode.COVER_RESTORE_AND_CALL,
}


def validate_range(config):
    if config[CONF_MIN_VALUE] > config[CONF_MAX_VALUE]:
        raise cv.Invalid(
            f"min_value ({config[CONF_MIN_VALUE]}) cannot be greater than max_value ({config[CONF_MAX_VALUE]})"
        )
    return config


CONFIG_SCHEMA = cv.All(
    cover.cover_schema(TuyaCover)
    .extend(
        {
            cv.GenerateID(CONF_TUYA_ID): cv.use_id(Tuya),
            cv.Optional(CONF_CONTROL_DATAPOINT): cv.uint8_t,
            cv.Optional(CONF_DIRECTION_DATAPOINT): cv.uint8_t,
            cv.Required(CONF_POSITION_DATAPOINT): cv.uint8_t,
            cv.Optional(CONF_POSITION_REPORT_DATAPOINT): cv.uint8_t,
            cv.Optional(CONF_MIN_VALUE, default=0): cv.int_,
            cv.Optional(CONF_MAX_VALUE, default=100): cv.int_,
            cv.Optional(CONF_INVERT_POSITION, default=False): cv.boolean,
            cv.Optional(CONF_INVERT_POSITION_REPORT, default=False): cv.boolean,
            cv.Optional(CONF_RESTORE_MODE, default="RESTORE"): cv.enum(
                RESTORE_MODES, upper=True
            ),
            cv.Optional(CONF_OPEN_VALUE, default=0x00): cv.hex_uint8_t,
            cv.Optional(CONF_CLOSE_VALUE, default=0x02): cv.hex_uint8_t,
            cv.Optional(CONF_STOP_VALUE, default=0x01): cv.hex_uint8_t,
        },
    )
    .extend(cv.COMPONENT_SCHEMA),
    validate_range,
)


async def to_code(config):
    var = await cover.new_cover(config)
    await cg.register_component(var, config)

    if CONF_CONTROL_DATAPOINT in config:
        cg.add(var.set_control_id(config[CONF_CONTROL_DATAPOINT]))
    if CONF_DIRECTION_DATAPOINT in config:
        cg.add(var.set_direction_id(config[CONF_DIRECTION_DATAPOINT]))
    cg.add(var.set_position_id(config[CONF_POSITION_DATAPOINT]))
    if CONF_POSITION_REPORT_DATAPOINT in config:
        cg.add(var.set_position_report_id(config[CONF_POSITION_REPORT_DATAPOINT]))
    cg.add(var.set_min_value(config[CONF_MIN_VALUE]))
    cg.add(var.set_max_value(config[CONF_MAX_VALUE]))
    cg.add(var.set_invert_position(config[CONF_INVERT_POSITION]))
    cg.add(var.set_invert_position_report(config[CONF_INVERT_POSITION_REPORT]))
    cg.add(var.set_restore_mode(config[CONF_RESTORE_MODE]))
    cg.add(var.set_open_value(config[CONF_OPEN_VALUE]))
    cg.add(var.set_close_value(config[CONF_CLOSE_VALUE]))
    cg.add(var.set_stop_value(config[CONF_STOP_VALUE]))
    paren = await cg.get_variable(config[CONF_TUYA_ID])
    cg.add(var.set_tuya_parent(paren))
